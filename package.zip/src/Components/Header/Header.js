import React from 'react'
import "./Header.scss"

function Header() {
  return (
    <div>Header</div>
  )
}

export default Header