import React from 'react'

import "./Blog.scss"

function Blog() {
  return (
    <div>Blog</div>
  )
}

export default Blog