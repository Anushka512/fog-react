import React from 'react'

import "./WishList.scss"

function WishList() {
  return (
    <div>WishList</div>
  )
}

export default WishList